package utils;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ExerciseUtilitiesTest1 {

    @Test
    void isOdd() {
        int num = 17;
        System.out.println(isOdd());
    }

    @Test
    void evenOut() {
    }
}